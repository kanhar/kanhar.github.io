document.querySelector("#nav-btn").addEventListener("click", () => {
    
    document.querySelector("#main-header").classList.toggle("show");

});